import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { libraryApi } from '@/services/library-api'
import type { LibraryOption } from '@/services/library-api'
import { errorMessage } from '@/services/http'

export type LibraryKind = 'departments' | 'divisions' | 'positions'
const CACHE_MS = 5 * 60 * 1000

// These are public reference records. Cache is memory-only, never localStorage.
export const useLibraryStore = defineStore('library', () => {
  const departments = ref<LibraryOption[]>([])
  const divisions = ref<LibraryOption[]>([])
  const positions = ref<LibraryOption[]>([])
  const updatedAt = ref<Record<LibraryKind, number>>({ departments: 0, divisions: 0, positions: 0 })
  const errors = ref<Partial<Record<LibraryKind, string>>>({})
  const pending = ref<Record<LibraryKind, boolean>>({ departments: false, divisions: false, positions: false })
  const inFlight: Partial<Record<LibraryKind, Promise<void>>> = {}

  async function load(kind: LibraryKind, force = false): Promise<void> {
    if (inFlight[kind]) return inFlight[kind]
    if (!force && updatedAt.value[kind] && Date.now() - updatedAt.value[kind] < CACHE_MS) return

    pending.value[kind] = true
    delete errors.value[kind]
    const promise = (async () => {
      try {
        const records = await libraryApi[kind]()
        if (kind === 'departments') departments.value = records
        else if (kind === 'divisions') divisions.value = records
        else positions.value = records
        updatedAt.value[kind] = Date.now()
      } catch (error) {
        errors.value[kind] = errorMessage(error)
        throw error
      } finally {
        pending.value[kind] = false
      }
    })()
    inFlight[kind] = promise
    try { await promise } finally { delete inFlight[kind] }
  }

  async function loadAll(force = false): Promise<void> {
    const results = await Promise.allSettled((['departments', 'divisions', 'positions'] as const)
      .map((kind) => load(kind, force)))
    if (results.every((result) => result.status === 'rejected')) {
      throw new Error('Unable to load Department, Division, and Position data.')
    }
  }

  const loading = computed(() => Object.values(pending.value).some(Boolean))
  const loadError = computed(() => Object.values(errors.value).filter(Boolean).join(' '))
  function invalidate(kind?: LibraryKind): void {
    if (kind) updatedAt.value[kind] = 0
    else updatedAt.value = { departments: 0, divisions: 0, positions: 0 }
  }
  function labelFor(kind: LibraryKind, id: number | null | undefined): string {
    if (id == null) return '—'
    const source = kind === 'departments' ? departments.value : kind === 'divisions' ? divisions.value : positions.value
    const record = source.find((option) => Number(option.id) === Number(id))
    return record?.alias || record?.name || `Unavailable (ID: ${id})`
  }

  return { departments, divisions, positions, pending, loading, errors, loadError, updatedAt,
    load, loadAll, invalidate, labelFor }
})
